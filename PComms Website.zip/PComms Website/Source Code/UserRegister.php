<?php
session_start();

include('server/connection.php');

if(isset($_POST['register'])){

    $fname = $_POST['first_name'];
    $lname = $_POST['last_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
    $day = $_POST['day'];
    $month = $_POST['month'];
    $year = $_POST['year'];
    $DOB = "$day/$month/$year";
    $contactNo = $_POST['contact_no'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    

    if(strlen($password)<1){
        header('location:UserRegister.php?error=Please fill up the form');
    }else if(strlen($password)<6){//if password less than 6 characters
            header('location:UserRegister.php?error=password must be at least 6 characters');

        }else{//if there is no error that run this 

            //check whether there is user with the same email
            $stmt1 = $conn->prepare("SELECT count(*) FROM Profile WHERE Email=?");
            
            $stmt1->bind_param('s',$email);
            $stmt1->execute();
            $stmt1->bind_result($num_rows);
            $stmt1->store_result();
            $stmt1->fetch();
        
       
            if($num_rows != 0){ //if there is a user with the same email
                header('location:UserRegister.php?error=This email already exists');

            }else{//If no user registered this email before

                //Create a new user
                $stmt = $conn->prepare("INSERT INTO Profile (FName,LName,Username,Password,Gender,DateOfBirth,ContactNo,Email,Address)
                                VALUES (?,?,?,?,?,?,?,?,?)");

                $stmt->bind_param('sssssssss',$fname,$lname,$username,md5($password),$gender,$DOB,$contactNo,$email,$address);
                
                //if account successfully created
                if($stmt->execute()){
                    $_SESSION['user_email'] = $email;
                    $_SESSION['user_name'] = $username;
                    $_SESSION['logged_in'] = true;
                    header('location:Login.php?register=You account have been registered successfully');
                }else{
                    header('location:UserRegister.php?error=could not create an account at the moment');
                }
            }
        }
    }
?>


<!DOCTYPE html>
<html>
    <head>
        <title>User Register</title>

        <style>
            body{
                background-color: #e0e0e0;
            }
            
            * {
                box-sizing: border-box;
            }

            .column1{
                flex: 10%;
                width: 10%;
                padding: 10px;
                border: 3px solid;
                margin-top:100px;
                margin-left:200px;
                height: 500px;
                border-top-left-radius:30px;
                border-bottom-left-radius:30px;
                background-color: white;
            }

            .column2{
                flex: 40%;
                width: 10%;
                padding: 10px;
                border: 3px solid;
                margin-top:100px;
                margin-right:200px;
                border-left:none;
                border-top-right-radius:30px;
                border-bottom-right-radius:30px;
                background-color: white;
            }

            .row{
                display:flex;
            }

            .img1{
                margin:130px;
                margin-left:55px;
            }

            .input1{
                border-radius:30px;
                border:2px solid;
                padding:5px;
            }

            .input1:focus{
                background-color:#45657b;
                color:white;
            }

            .input1::placeholder{
                font-size: 14px;
            }

            .signup{
                font-family: monospace;
                font-size:35px;
            }

            select{
                border-radius:100px;
                border:2px solid;
                padding:5px;
                font-family: monospace;
            }

            select:focus{
                background-color:#45657b;
                color:white;
            }  

            .word{
                font-family: monospace;
                font-size:19px;
            }

            button:focus{
                background-color:#45657b;
                color:white;
            }

            button a{
                text-decoration:none;
                color:black;
            }

            #upper{
                font-weight: bold;
            }

            .btn{
                padding: 10px 30px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
                margin-left: 20px;
                
            }

            input[type=text],input[type=password]{
                text-align: center;
            }

            .warning{
                position: absolute;
                margin-top:auto;
                margin-left:auto;
                text-align:center;
            }
        </style>
    </head>

    <body>
        <center>
            <div class="row">
                <div class="column1">
                    <img src="../Resources/Web Application.png" width="200px" class="img1">
                </div>

                <div class="column2">
                    <p1 class="signup">Sign Up</p1>

                    <br><br>
                    <form method="POST" action="UserRegister.php">
                    <?php if(isset($_GET['error'])){ ECHO '<script>alert("'.$_GET['error'].'");</script>';}?>
                    <table>
                        <tr>
                            <td class="word" id="upper">Username</td>
                            <td>: &nbsp;<input type="text" class="input1" style="width:500px;" name="username" placeholder="Username"></td>
                        </tr>


                        <td></td><tr></tr><td></td><tr></tr>

                        <tr>
                            <td class="word" id="upper">First Name</td>
                            <td>: &nbsp;<input type="text" class="input1" style="width:187px;" name="first_name" placeholder="First Name"> &nbsp;&nbsp; 
                                <p1 class="word" id="upper">Last Name</p1> : &nbsp;<input type="text" class="input1" style="width:187px;" name="last_name" placeholder="Last Name"></td>
                        </tr>

                        <td></td><tr></tr><td></td><tr></tr>

                        <tr>
                            <td class="word" id="upper">Password</td>
                            <td>: &nbsp;<input type="password" class="input1" style="width:500px;" name="password" placeholder="Password"></td>
                        </tr>

                        <td></td><tr></tr><td></td><tr></tr>

                        <tr>
                            <td class="word" id="upper">Gender</td>
                            <td>
                                : &nbsp;<input type="text" class="input1" style="width:106px;" name="gender" placeholder="M/F"> &nbsp;&nbsp; 
                                <p1 class="word" id="upper">Date of Birth </p1>:
                                    <select name="day">
                                        <option>01</option> <option>02</option> <option>03</option> <option>04</option>
                                        <option>05</option> <option>06</option> <option>07</option> <option>08</option>
                                        <option>09</option> <option>10</option> <option>11</option> <option>12</option>
                                        <option>13</option> <option>14</option> <option>15</option> <option>16</option>
                                        <option>17</option> <option>18</option> <option>19</option> <option>20</option>
                                        <option>21</option> <option>22</option> <option>23</option> <option>24</option>
                                        <option>25</option> <option>26</option> <option>27</option> <option>28</option>
                                        <option>29</option> <option>30</option> <option>31</option>
                                    </select>

                                    <select name="month">
                                        <option>January</option> <option>February</option> <option>March</option> 
                                        <option>April</option> <option>May</option> <option>June</option> <option>July</option> 
                                        <option>August</option> <option>September</option> <option>October</option> 
                                        <option>November</option> <option>December</option>
                                    </select>

                                    <select name="year">
                                        <option>1990</option> <option>1991</option> <option>1992</option> <option>1993</option>
                                        <option>1994</option> <option>1995</option> <option>1996</option> <option>1997</option>
                                        <option>1998</option> <option>1999</option> <option>2000</option> <option>2001</option>
                                        <option>2002</option> <option>2003</option> <option>2004</option> <option>2005</option>
                                        <option>2006</option> <option>2007</option> <option>2008</option> <option>2009</option>
                                        <option>2010</option> <option>2011</option> <option>2012</option> <option>2013</option> 
                                        <option>2014</option> <option>2015</option> <option>2016</option> <option>2017</option> 
                                        <option>2018</option> <option>2019</option> <option>2020</option> <option>2021</option>
                                        <option>2022</option> <option>2023</option> <option>2024</option>
                                    </select>
                            </td>
                        </tr>

                        <td></td><tr></tr><td></td><tr></tr>

                        <tr>
                            <td class="word"id="upper">Contact No</td>
                            <td>: &nbsp;<input type="text" class="input1"  name="contact_no" style="width:500px;" placeholder="012-333-4444"></td>
                        </tr>

                        <td></td><tr></tr><td></td><tr></tr>

                        <tr>
                            <td class="word" id="upper">Email</td>
                            <td>: &nbsp;<input type="text"  name="email" class="input1" style="width:500px;" placeholder="abc@gmail.com"></td>
                        </tr>

                        <td></td><tr></tr><td></td><tr></tr>

                        <tr>
                            <td class="word" id="upper">Address</td>
                            <td>: &nbsp;<input type="text" name="address" class="input1" style="width:500px; height:60px;" placeholder="Your Address"></td>
                        </tr>

                        <td></td><tr></tr><td></td><tr></tr>



                        <td></td><tr></tr><td></td><tr></tr><td></td>

                        <tr>
                            <td><p class="bbtn"><a href="Login.php" class="btn">CANCEL</a></p></td>
                            <td>
                                <div class="bbtn">
                                    <input type="submit" class="btn" name="register" value="CONFIRM"/>
                                </div>
                            </td>
                        </tr>
                    </table>
                    </form>
                </div>
            </div>
        </center>

        <script type="text/javascript">
            function confirm(){
                alert("Account Created!");
            }
        </script>
    </body>
</html>