<!DOCTYPE html>
<html>
    <head>
        <title>Community Tab</title>

        <style>
            /*Banner*/
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
            }

            .img{
                width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
                right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }


            /*Content*/
            .btn1{
                background-color:white;
                border-radius: 20px;
                border:2px solid;
                padding:40px;
                width:210px;
                font-size:20px;
                font-family: monospace;
                float:left;
                margin-left:-725px;
                margin-top:-90px;
                cursor:pointer;
                position:fixed;
                text-decoration: none;
                color: #740c03;
                border: 2px solid black;
            }   

            p a:hover{
                background-color: #740c03;
                color: white;
                font-weight: bold;
                border-color: white;
                border: 2px solid white;
            }

            button a{
                text-decoration:none;
                color:black;
            }

            .UserDiscussion1{
                display: flex;
                border: 3px solid black;
                border-radius: 30px;
                width: 470px;
                height:140px;
                margin-right:180px;
                max-width: 470px;
                max-height:140px;
            }

            .UserDiscussion2{
                display: flex;
                border: 3px solid black;
                border-radius: 30px;
                width: 470px;
                height:140px;
                margin-top:-144px;
                margin-right:-900px;
                max-width: 470px;
                max-height:140px;
            }

            .Userimg2{
                border: 3px solid black;
                border-radius: 25px;
                width: 149px;
                max-width: 210px;
                height:138px;
                max-height: 138px;
            }

            .UserBanner{
                font-family: monospace;
                padding: 10px 20px;
                font-size: 20px;
                letter-spacing: 2px;
            }

            h3.User{
                text-align: left;
            }

            h3{
                text-align: left;
                font-size: 15px;
            }

            h3.User a:visited,h3.User a:link{
                font-size: 20px;
                letter-spacing: 0px;
                color: black;
            }

            h3.User a:hover{
                color: #45657b;
            }

            h3.User a:active{
                color: #ffbd59;
            }

            h3 a{
                text-decoration:underline;
                color:black;
            }

            li a{
                text-decoration:none;
                color:black;
            }

            .UserDescription{
                letter-spacing: 0px;
                font-size:15px;text-align: left;
            }

            .DiscussionTitle{
                font-family: monospace;
                border:2px solid;
                border-radius:30px;
                width:800px;
                margin-left:360px;
            }

            .category{
                position: fixed;
                font-family: monospace;
                border: 3px solid black;
                border-radius: 30px;
                width: 300px;
                margin-left: 50px;
                margin-top:-240px;
                height:450px;

            }

            h1{
                font-size: 35px;
            }

            li{
                font-size: 20px;
                padding: 6px;
            }

            #top1{
                font-family: monospace;
                font-size: 30px;
                line-height: 55px;
                margin-left: 362px;
                background-color: #45657b;
                width: 1100px;
                height: 50px;
                border-bottom: 5px solid #ffbd59;
            }

            .btn{
                position: fixed ;
                margin-left: 640px;
                margin-top: 120px;
                padding: 10px 20px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
            }


            /*Sticky*/
            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }

            li a:link,li a:visited{
                color: #45657b;
                text-decoration: none;
            }

            li a:hover{
                color: #740c03;
                font-weight: bold;
            }

            li a:active{
                color: #ffbd59;
            }
            
            
            h1 a:link,h1 a:visited{
                color: #740c03;
            }

            h1 a:hover{
                color: #d54336;
            }
            
            h1 a:active{
                color: #ffbd59;
            }

            h1 a.forum:link,h1 a.forum:visited{
                text-decoration: none;
                color: black;
            }

            h1 a.forum:hover{
                color:#45657b;

            }
            
            h1 a.forum:active{
                color: #ffbd59;
            }
        </style>
    </head>

    <body>
        <!--Banner-->
        <header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

            <!--Sticky-->
            <div class="ContactUs">
                <a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
                <div class="ContactUsWord">
                    <a href="ContactUs.php">CONTACT US</a>
                </div>
            </div>

            <!--Content-->
            <br><br><br><br><br><br><br>
            <center>
                <caption id="top">
                    <div id="top1">
                        <p><font style="color: white;">COMMUNITY TAB</font></p>
                    </div>
                </caption>
                <br><br>

                <div class="UserDiscussion1">
                    <img src="../Resources/kun.jpg" class="Userimg2">
                    <div class="UserBanner">
                        <h3 class="User"><a href="Forum.php">How to apply a Screen Protector?</a></h3>
                        <h3>Tan Yi Yan</h3>
                        <br>
                        <p class="UserDescription">Step-by-step teach you how to apply a Screen Protector.</p>
                    </div>
                </div>

                <div class="UserDiscussion2">
                    <img src="../Resources/Ikun_with_no_bg_vect.webp" class="Userimg2">
                    <div class="UserBanner">
                        <h3 class="User"><a href="Forum1.php">Why choose Almarai Powder Milk?</a></h3>
                        <h3>Muhamad WAHAHA</h3>
                        <br>
                        <p class="UserDescription">Almarai Powder Milk the best choice to protect your Family.</p>
                    </div>
                </div>

                <div class="category">
                    <br>
                    <h1><a href="#top" class="categoryTitle">Viewed Forum</a></h1>
                    <br><br>
                        <table>
                            <tr>
                                <td>
                                    <li><a href="#">A</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#c">D</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#f">G</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#i">J</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li> 
                                    <li><a href="#l">M</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#o">P</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li> 
                                    <li><a href="#r">S</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#u">V</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#x">Y</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                </td>
                                
                                <td>
                                    <li><a href="#">B</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#d">E</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>    
                                    <li><a href="#g">H</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#j">K</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li> 
                                    <li><a href="#m">N</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#p">Q</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#s">T</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                    <li><a href="#v">W</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li> 
                                    <li><a href="#y">Z</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
                                </td>
                                
                                <td>
                                    <li><a href="#">C</a></li>
                                    <li><a href="#e">F</a></li>
                                    <li><a href="#h">I</a></li>
                                    <li><a href="#k">L</a></li>
                                    <li><a href="#n">O</a></li>
                                    <li><a href="#q">R</a></li>
                                    <li><a href="#t">U</a></li>
                                    <li><a href="#w">X</a></li>
                                    <li><a href="##">#</a></li>
                                </td>
                            </tr>
                        </table>
                        <br>
                </div>

                <div>
                    <br><br>
                    <h1 class="DiscussionTitle"><a href="#" class="forum">A</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="c"><a href="#" class="forum">B</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="d"><a href="#" class="forum">C</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="e"><a href="#" class="forum">D</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="f"><a href="#" class="forum">E</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="g"><a href="#" class="forum">F</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="h"><a href="#" class="forum">G</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="i"><a href="#" class="forum">H</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="j"><a href="#" class="forum">I</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="k"><a href="#" class="forum">J</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="l"><a href="#" class="forum">K</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="m"><a href="#" class="forum">L</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="n"><a href="#" class="forum">M</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="o"><a href="#" class="forum">N</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="p"><a href="#" class="forum">O</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="q"><a href="#" class="forum">P</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="r"><a href="#" class="forum">Q</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="s"><a href="#" class="forum">R</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="t"><a href="#" class="forum">S</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="u"><a href="#" class="forum">T</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="v"><a href="#" class="forum">U</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="w"><a href="#" class="forum">V</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="x"><a href="#" class="forum">W</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="y"><a href="#" class="forum">X</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="z"><a href="#" class="forum">Y</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="#"><a href="#" class="forum">Z</a></h1> <br><br>
                    <h1 class="DiscussionTitle" id="#"><a href="#" class="forum">#</a></h1> <br><br>
                </div>
            </center>
            <br><br><br><br><br><br><br>
    </body>
</html>