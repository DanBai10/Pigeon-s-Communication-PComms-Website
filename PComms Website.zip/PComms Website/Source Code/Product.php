<?php

include('server/connection.php');

if(isset($_GET['ProductID'])){

    $product_id =$_GET['ProductID'];

    $stmt = $conn->prepare("SELECT * FROM PRODUCT WHERE ProductID = ?");
    $stmt->bind_param("s",$product_id);

    $stmt->execute();

    $product = $stmt->get_result();

}else{
    header('location: home.php');
}

?>




<!DOCTYPE html>
<html>
    <head>
        <title>Product Page</title>
    </head>

    <body>
        <style>
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
            }

            .img{
                width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
				right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }

            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }

			.Image{
				width: 450px;
				height: 350px;
				position: absolute;
				top: 140px;
				left: 226px;
				border: 3px solid black;
				border-radius:20px;
			}

			.Product{
				position: absolute;
				top: 140px;
				left: 750px;
				text-align:left;
			}
			
			.ProductTitle{
				font-weight:bold;
				font-size:35px;
				text-decoration:underline;
				font-family: monospace;
                letter-spacing: 2px;
			}
			
			.qStyle{
				border-radius:10px;
				border: 2px solid black;
				width:60px;
				text-align:center;
			}

			.btn1{
				border-radius:30px;
				border: 2px solid black;
				width:460px;
				height:45px;
				font-size:20px;
				font-family: monospace;
                letter-spacing: 2px;
			}

			.price{
				font-size:25px;
				font-family: monospace;
                letter-spacing: 2px;
			}
		
			.quantity{
				font-size:20px;
				font-family: monospace;
                letter-spacing: 2px;
			}
		
			li.liShop{
				display:inline-block;
			}
		
			.ShopN{
				font-size:20px;
				font-family: monospace;
                letter-spacing: 2px;
                font-weight: bold;
			}

			.viewShop{
				font-size:15px;
				font-family: monospace;
                letter-spacing: 2px;
				border-radius:20px;
				padding-top:2px;
				padding-bottom:2px;
				padding-left:15px;
				padding-right:15px;
				border: 2px solid black;
			}
			
			.ProductD{
				position: absolute;
				top: 500px;
				left:240px;
			}
			
			.proD{
				font-size:20px;
				text-align:left;
				font-family: monospace;
                letter-spacing: 2px;
                width: 1200px;
                letter-spacing: 0px;
			}

			.proContent{
				font-size:25px;
				text-align:left;
				font-family: monospace;
                letter-spacing: 2px;
			}
			
			.qStyle:focus{
				background:#45657b;
				color:white;
			}
			
			.btn1:hover{
                cursor: pointer;
				background:#45657b;
				color:#ffbd59;
			}
			
			.viewShop:hover{
				background:#45657b;
				color:#ffbd59;
			}

            .btn{
                padding: 10px 30px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
                margin-left: 20px;
            }

            p a:hover{
                background-color: #740c03;
                color: white;
                font-weight: bold;
                border-color: white;
            }
        </style>

<header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

<!-- Product-->
	<div class="Product">

    <?php while($row = $product->fetch_assoc()){?>

    <form method="POST" action="ShoppingCart.php">
        <input type="hidden" name="product_id" value="<?php ECHO $row['ProductID'];?>"/>
        <input type="hidden" name="product_image" value="<?php ECHO $row['Image'];?>"/>
        <input type="hidden" name="product_name" value="<?php ECHO $row['ProductName'];?>"/>
        <input type="hidden" name="product_price" value="<?php ECHO $row['Price'];?>"/>

		<p class="ProductTitle"><?php ECHO $row['ProductName'];?></p>
        <p class="price"><b>ProductID:</b></p>
        <p class="price"><?php ECHO $row['ProductID'];?> </p>
        <br>
        <p class="price"><b>Price:</b></p>
		<p class="price"> RM <?php ECHO $row['Price'];?> </p>	
        <br>
        <p class="price"><b>Quantity:</b></p>
		<input type="number" name="product_quantity" value="1" class="qStyle"/>	
		<br><br><br><br>

		
		<button class="btn1" type="submit" name="add_to_cart"> Add to Cart </button>
	</div>

    <!--Product Picture -->
            <img src="../Resources/<?php ECHO $row['Image'];?>" class="Image">
    <!-- Product Description -->
        <div class="ProductD">
            <br>
            <p class="proD"><?php ECHO $row['Description'];?></p>
        </div>

    </form>
    <?php }?>


		<div class="ContactUs">
			<a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
			<div class="ContactUsWord">
				<a href="ContactUs.php">CONTACT US</a>
			</div>
		</div>
	</div>
    </body>
</html>
