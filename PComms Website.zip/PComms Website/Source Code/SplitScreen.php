<!DOCTYPE html>
<html>
    <head>
        <title>Split Screen</title>
    </head>
    <frameset rows = "50%, 50%">
        <frame src="Home.php"></frame>
        <frame src="Home.php"></frame>
    </frameset>
</html>