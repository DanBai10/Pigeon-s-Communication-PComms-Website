<?php

$conn = mysqli_connect("localhost","root","","pcomms") 
        or die("Can't Connect to the Database!") 

?>