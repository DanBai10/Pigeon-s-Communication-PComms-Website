<?php 

session_start();

include('connection.php');

    if(isset($_POST['place_order'])){

        $fname=$_POST['first_name'];
        $lname=$_POST['last_name'];
        $email=$_POST['email'];
        $contact=$_POST['contact_no'];
        $address=$_POST['address'];
        $order_cost=$_SESSION['total'];
        $order_status = "on_hold";
        $order_date = date('Y-m-d H:i:s');

        $stmt = $conn->prepare("INSERT INTO orders (order_cost,order_status,firstname,lastname,email,contactNo,address,order_date)
                        VALUES (?,?,?,?,?,?,?,?); ");   

        $stmt->bind_param('isssssss',$order_cost,$order_status,$fname,$lname,$email,$contact,$address,$order_date);

        $stmt->execute();

        $order_id = $stmt->insert_id;

        foreach($_SESSION['cart']as $key => $value){

            $product = $_SESSION['cart'][$key];
            $product_id=$product['product_id'];
            $product_image=$product['product_image'];
            $product_name=$product['product_name'];
            $product_price=$product['product_price'];
            $product_quantity=$product['product_quantity'];

            $stmt1 = $conn->prepare("INSERT INTO OrderItem(order_id,ProductID,Image,ProductName,product_price,product_quantity,order_date)
                            VALUES (?,?,?,?,?,?,?); ");

            $stmt1->bind_param('isssiis',$order_id,$product_id,$product_image,$product_name,$product_price,$product_quantity,$order_date);

            $stmt1->execute();
            
            $_SESSION['order_id'] = $order_id;
            $_SESSION['order_date'] = $order_date;

        }

        header('location:../TransactionCompleted.php?order_status="order placed successfully"');

    }else{

    }

?>