<!DOCTYPE html>
<html>
    <head>
        <title>Video</title>
    </head>

    <body>
        <style>
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
            }

            .img{
                width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
                right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }

            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }
			
			.slidershow{
				width: 550px;
				height: 310px;
				overflow: hidden;
			}
			.middle{
				position: absolute;
				margin-top: 135px;
				left: 160px;
				border: 3px solid black;
				border-radius:20px;
			}

			.navigation{
				background:none;
				position: absolute;
				top: 92%;
				right: 3%;
				display: flex;
				transform: translateX(-50%);
			}

			.bar{
				width: 50px;
				height: 10px;
				border: 2px solid black;
				margin: 6px;
				cursor: pointer;
				transition: 0.4s;
				background-color:#fff;
			}
			.bar:hover{
				background:#45657b;
			}

			.bar:active{
				background:#ffbd59;
			}

			input[name="r"]{
				position: absolute;
				visibility: hidden;
			}

			.slides{
				width:500%;
				height: 100%;
				display: flex;
			}

			.slide{
				width: 20%;
				transition: 0.6s;
			}

			#r1:checked ~ .s1{
				margin-left: 0;
			}
			#r2:checked ~ .s1{
				margin-left: -20%;
			}
			#r3:checked ~ .s1{
				margin-left: -40%;
			}
			#r4:checked ~ .s1{
				margin-left: -60%;
			}
			
			.vInfo{
				position: absolute;
				margin-top: 135px;
				left: 750px;
				text-align:left;
			}
			
			.vInfo a:link{
				color:black;
			}
			
			.vInfo a:visited{
				color:black;
			}
			
			.vInfo a:hover{
				color: #45657b;
			}
			
			.vInfo a:active{
				color: #ffbd59;
			}
			
			.ppInfo{
				text-decoration:none;
			}
			
			.vTitle{
				font-weight:bold;
				font-size:35px;
				text-decoration:underline;
				font-family: monospace;
                letter-spacing: 0px;
			}
			
			.pName{
				font-size:25px;
				font-family: monospace;
                letter-spacing: 2px;
				font-weight: bold;
			}
			
			.vDesc{
				font-size:20px;
				font-family: monospace;
                letter-spacing: 2px;
			}

            .Product11{
                display: flex;
                width: 1000px;
                padding: 50px;
                margin-left: 200px;
                line-height: 30px;
            }

            .ProductBanner{
                font-family: monospace;
                padding: 10px 20px;
                font-size: 20px;
                letter-spacing: 2px;
                text-align: left;
            }

            .Productimg1{
                border: 3px solid black;
                border-radius: 25px;
                width: 220px;
                max-width: 220px;
                height: 220px;
            }

            .ProductDescription1{
                text-align: right;
            }

            h1 a:link,h1 a:visited{
                color: black;
                font-size: 30px;
            }

            h1 a:hover{
                color: #45657b;
            }

            h1 a:active{
                color: #ffbd59;
            }
			
        </style>

<header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

<!--Slide Show -->
	<div class="slidershow middle">
		<div class="slides">
				<input type="radio" name="r" id="r1" checked>
				<input type="radio" name="r" id="r2">
				<input type="radio" name="r" id="r3">
				<input type="radio" name="r" id="r4">
			<div class="slide s1" >
				<a target="_blank" href="https://www.youtube.com/watch?v=JumeqCM-dRI">
					<video width="100%" height="100%" controls autoplay muted loop> 
						<source src ="../Resources/How to apply a screenprotector - Tutorial.mp4" type="video/mp4">
					</video>
				</a>
			</div>
			<div class="slide">
				<a target="_blank" href="https://www.youtube.com/watch?v=QqCDKc6Q8AU">
					<video width="100%" height="100%" controls autoplay muted loop> 
						<source src ="../Resources/Almarai Powder Milk TV Commercial.mp4" type="video/mp4">
					</video>
				</a>
			</div>
			<div class="slide">
				<a target="_blank" href="https://www.youtube.com/watch?v=BpnW2ghqI1U">
					<video width="100%" height="100%" controls autoplay muted loop> 
						<source src ="../Resources/Silicone spatulas TESCOMA PRESTO.mp4" type="video/mp4">
					</video>
				</a>
			</div>
			<div class="slide">
				<a target="_blank" href="https://www.youtube.com/watch?v=0OJsM3jAQQ4">
					<video width="100%" height="100%" controls autoplay muted loop> 
						<source src ="../Resources/How to Use a Clay Pot.mp4" type="video/mp4">
					</video>
				</a>
			</div>
		</div>
	
		<div class="navigation">
			<label for="r1" class="bar" id="bar1"></label>
			<label for="r2" class="bar" id="bar2"></label>
			<label for="r3" class="bar" id="bar3"></label>
			<label for="r4" class="bar" id="bar4"></label>
		</div>
	</div>
<!-- 
	id="bar1" -- "bar4" can be used in javascript later on to change the prouct name and description if needed
-->	
	
<!-- Video's Procduct Info-->
	<div class="vInfo">
		<a target="_blank" href="https://www.youtube.com/watch?v=JumeqCM-dRI" id="link"> <p class="vTitle" id="vTitleJ">How to apply a Screen Protector?</p> </a>
        <p class="pName" id="pNameJ"> Screen Protector</p> </a>
		<br><br>
		<p class="vDesc" id="vDescJ">Step-by-step teach you how to apply a Screen Protector.</p>
	</div>


<!--Contact Us -->
    <div class="ContactUs">
        <a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
        <div class="ContactUsWord">
            <a href="ContactUs.php">CONTACT US</a>
        </div>
    </div>


<!-- Others info -->
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br>



<!-- Others info -->

<table>
	<?php include('server/get_product.php');?>
	<?php while($row = $product->fetch_assoc()){?>
        <tr>
            <td>
                <div class="Product11">
                <img src="../Resources/<?php ECHO $row['Image'];?>" class="Productimg1">
                    <div class="ProductBanner">
                        <h1 class="ProductDescription"><a href="<?php ECHO "Product.php?ProductID=".$row['ProductID'];?>"><?php ECHO $row['ProductName'];?></a></h1>
                        <br>
                        <br><br><br><br>
                        <p class="ProductDescription">RM<?php ECHO $row['Price'];?></p>
                    </div>
                </div>
            </td>
        </tr>
	<?php }?>
</table>


	<script type = "text/javascript">
		bar1.addEventListener("click", function() {
		vTitleJ.textContent = "How to apply a Screen Protector?";
		pNameJ.textContent = "Screen Protector";
		vDescJ.textContent = "Step-by-step teach you how to apply a Screen Protector.";
		var newURL = "https://www.youtube.com/watch?v=JumeqCM-dRI";  //This changes the <a> for the title(video) 1 to title 1
        document.getElementById("link").href = newURL;
		});
		
		bar2.addEventListener("click", function() {
		vTitleJ.textContent = "Almarai Powder Milk TV Commercial.";
		pNameJ.textContent = "Almarai Powder Milk";
		vDescJ.textContent = "Almarai Powder Milk the best choice to protect your Family.";
		var newURL = "https://www.youtube.com/watch?v=QqCDKc6Q8AU&ab_channel=%D8%A7%D9%84%D9%85%D8%B1%D8%A7%D8%B9%D9%8AAlmarai"; //This changes the <a> for the title(video) 1 to title 2
        document.getElementById("link").href = newURL;
		});
		
		bar3.addEventListener("click", function() {
		vTitleJ.textContent = "Silicone spatulas -- TESCOMA PRESTO.";
		pNameJ.textContent = "TESCOMA PRESTO Silicone spatulas";
		vDescJ.textContent = "- Excellent for use in cookware with non-stick coating; it will not damage the surface.";
		var newURL = "https://www.youtube.com/watch?v=BpnW2ghqI1U&ab_channel=tescomavideoEN"; //This changes the <a> for the title(video) 1 to title 3
        document.getElementById("link").href = newURL;
		});
		
		bar4.addEventListener("click", function() {
		vTitleJ.textContent = "How to Use a Clay Pot?";
		pNameJ.textContent = "Clay Pot";
		vDescJ.textContent = "I hope you like my new product and have fun cooking with it =)";
		var newURL = "https://www.youtube.com/watch?v=0OJsM3jAQQ4&ab_channel=SoupedUpRecipes"; //This changes the <a> for the title(video) 1 to title 4
        document.getElementById("link").href = newURL;
		});
		
	</script>
	
    </body>
</html>
