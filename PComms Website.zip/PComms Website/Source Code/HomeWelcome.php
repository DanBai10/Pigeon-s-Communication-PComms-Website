<?php

session_start();

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
    </head>

    <body>
        <style>
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
            }

            .img{
                width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
                right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }

            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }

            .BounceBanner{
                display: block;
                position: relative;
                margin-left: 150px;
                padding:0;
                box-sizing: border-box;
                border: 3px solid black;
                border-radius: 50px;
                width:1250px;
                max-width: 1250px;
                height: 340px;
            }

            marquee{
                height:50vh;
            }

            .BounceBannerTitle{
                font-family: monospace;
                margin-top: 110px;
                margin-left: 190px;
                position: absolute;
                font-size: 85px;
                width: 900px;
                letter-spacing: 3px;
            }

            .UserDiscussion{
                display: flex;
                border: 3px solid black;
                border-radius: 30px;
                width: 1000px;
                margin: auto;
                text-align:left;
            }

            .Userimg1{
                border: 3px solid black;
                border-radius: 25px;
                width: 27%;
            }

            .Userimg2{
                border: 3px solid black;
                border-radius: 25px;
                width: 275px;
                height: 275px;
                background-color: white;
            }

            .UserBanner{
                font-family: monospace;
                padding: 10px 20px;
                font-size: 25px;
                letter-spacing: 2px;
            }

            h1.User{
                text-align: left;
            }

            h3{
                text-align: left;
                font-size: 20px;
            }

            h1.User a:visited,h1.User a:link,h1.Shop a:visited,h1.Shop a:link{
                letter-spacing: 1px;
                font-size: 35px;
                color: black;
            }

            h1.User a:hover{
                color: #45657b;
            }

            h1.Shop a:hover{
                font-size:35px;
                color: #45657b;
            }
            
            h1.User a:active,h1.Shop a:active{
                color: #ffbd59;
            }
            
            .UserDescription{
                letter-spacing: 0px;
            }

            .ShopBanner{
                font-family: monospace;
            }

            .Shopimg1{
                border: 3px solid black;
                border-radius: 25px;
                width: 250px;
                max-width: 250px;
                margin: 45px;
                height:250px;
            }
            
            .AllShop{
                display: inline-block;
            }

            .banner1{
                font-family: monospace;
                font-size: 30px;
                line-height: 55px;
                margin: auto;
                background-color: #45657b;
                width: 1050px;
                height: 50px;
                border-bottom: 5px solid #ffbd59;
            }

            .banner1 a:link,.banner1 a:visited{
                color: white;
                text-decoration: none;
            }

            .banner1 a:hover{
                color: #740c03;
            }

            .banner1 a:active{
                color: #ffbd59;
            }

        </style>

<header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

<div class="ContactUs">
    <a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
    <div class="ContactUsWord">
        <a href="ContactUs.php">CONTACT US</a>
    </div>
</div>

    <br><br><br><br><br><br>
    <br><br><br><br><br>

    <div class="BounceBanner">
        <h1 class="BounceBannerTitle">Welcome To <font style="color:#45657b;">P</font><font style="color:#ffbd59;">COMMS</font>!</h1>
        <marquee behavior="alternate" scrollamount="30">
            <marquee behavior="alternate" scrollamount="30" direction="down">
                <img src="../Resources/Web Application.png" style="width:100px;height:100px;">
            </marquee>
        </marquee>
    </div>
    
    <br><br><br><br><br><br><br>

    <div class="banner1">
        <p><a href="Community.php">COMMUNITY</a></p>
    </div>
    <br><br>

    <div class="UserDiscussion">
        <img src="../Resources/kun.jpg" class="Userimg1">
        <div class="UserBanner">
            <h1 class="User"><a href="Forum.php">How to apply a Screen Protector?</a></h1>
            <h3>Tan Yi Yan</h3>
            <br>
            <p class="UserDescription">Step-by-step teach you how to apply a Screen Protector.</p>
        </div>
    </div>

    <br><br><br><br><br><br>
    <div class="banner1">
        <p><a href="Shop.php">SHOP</a></p>
    </div>

    <div class="AllShop">
        <table>
            <tr>
                <td><a href="Accessories.php"><img src="../Resources/accessories.png" class="Shopimg1"></a></td>
                <td><a href="BabyStore.php"><img src="../Resources/baby.jpeg" class="Shopimg1"></a></td>
                <td><a href="Cookware.php"><img src="../Resources/cook.jpg" class="Shopimg1"></a></td>
            </tr>

            <tr>
                <td><h1 class="Shop"><a href="Accessories.php">Accessories</a><h1></td>
                <td><h1 class="Shop"><a href="BabyStore.php">Baby Store</a><h1></td>
                <td><h1 class="Shop"><a href="Cookware.php">Cookware</a><h1></td>
            </tr>
        </table>
    </div>
    <br><br><br><br><br><br><br>

    <script type="text/javascript">
       alert("Hi <?php ECHO $_SESSION['Username']?>! Welcome to PComms!");
    </script>
    
    </body>
</html>