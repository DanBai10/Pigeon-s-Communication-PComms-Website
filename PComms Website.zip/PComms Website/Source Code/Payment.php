<?php

session_start();

if(!empty($_SESSION['cart']) && isset($_POST['checkout'])){

}else{ 
    header('location: home.php');
}

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Payment</title>

        <style>
            body{
                background-color: #e0e0e0;
                font-family: monospace;
            }

            .box{
                width: 1000px;
                height:500px;
                padding: 10px;
                border: 3px solid;
                border-radius:30px;
                background-color: white;
            }

            .card{
                padding: 15px;
                width: 900px;
                height: 450px;
                margin: auto;
                font-size: 20px;
            }

            .select1{
                border-radius: 30px;
                font-family: monospace;
                font-weight: bold;
                font-size: 18px;
                border:2px solid black;
            }

            .select1:hover{
                background-color: #45657b;
                color: white;
            }

            .btn{
                padding: 10px 30px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
                position:absolute;
                margin-left:180px;
                margin-top:-30px;
            }

            p a:hover{
                background-color: #740c03;
                color: white;
                font-weight: bold;
                border-color: white;
            }

            .select2{
                border-radius:100px;
                border:2px solid;
                padding:5px;
                font-family: monospace;
            }

            .select2:hover{
                background-color:#45657b;
                color:white;
            } 

            .input1{
                border-radius:30px;
                border:2px solid;
                width:215px;
                padding:5px;
            }

            .input1:focus{
                background-color:#45657b;
                color:white;
            }

            input[type=text]{
                text-align: center;
            }

            .CardDetails{
                text-align: left;
                font-weight: bold;
                font-family: monospace;
                text-decoration: underline;
                font-size: 24px;
                position: absolute;
                margin-left: 20px;
                margin-top: 10px;
            }
            
        </style>
    </head>

    <body>
        <br><br><br><br><br>
        <center>

            <div class="box">
                <p class="CardDetails">Payment Details</p>
                <br><br>
                <table class="card">
                <form method="POST" action="server/place_order.php">
                    <tr>
                        <td>First Name</td>
                        <td>: <input type="text" class="input1" name="first_name" placeholder="First Name"></td>
                        <td>Last Name</td>
                        <td>: <input type="text" class="input1" name="last_name" placeholder="Last Name"></td>
                    </tr>

                    <tr>
                        <td>Email</td>
                        <td>: <input type="text" class="input1" name="email" placeholder="abc@gmail.com"></td>
                        <td>Contact No</td>
                        <td>: <input type="text" class="input1" name="contact_no" placeholder="012-1234567"></td>
                    </tr>
        
                    <tr>
                        <td>Address</td>
                        <td>: <input type="text" class="input1" name="address" placeholder="Your Address"></td>
                    </tr>

                    <tr>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td><input type="submit" class="btn" name="place_order" value="CHECK OUT"></td>
                    </tr>
                </form>
                </table>
            </div>
        </center>

        <script type="text/javascript">
            function confirm(){
                alert("Transaction Completed!");
            }
        </script>
    </body>
</html>