<?php

session_start();

if(isset($_POST['add_to_cart'])){

    if(isset($_SESSION['cart'])){

        $product_array_ids = array_column($_SESSION['cart'],"product_id");

        if(!in_array($_POST['product_id'], $product_array_ids)){

            $product_id = $_POST['product_id'];

            $product_id = $_POST['product_id'];
            $product_image = $_POST['product_image'];
            $product_name = $_POST['product_name'];
            $product_price = $_POST['product_price'];
            $product_quantity = $_POST['product_quantity'];
    
            $product_array = array(
                             'product_id' => $product_id,
                             'product_image' => $product_image,
                             'product_name' => $product_name,
                             'product_price' => $product_price,
                             'product_quantity' => $product_quantity,
            );
    
            $_SESSION['cart'][$product_id] = $product_array;

        }else{

        }

    }else{

        $product_id = $_POST['product_id'];
        $product_image = $_POST['product_image'];
        $product_name = $_POST['product_name'];
        $product_price = $_POST['product_price'];
        $product_quantity = $_POST['product_quantity'];

        $product_array = array(
                         'product_id' => $product_id,
                         'product_image' => $product_image,
                         'product_name' => $product_name,
                         'product_price' => $product_price,
                         'product_quantity' => $product_quantity,
        );

        $_SESSION['cart'][$product_id] = $product_array;
    }

    calcTotalcart();

}else if(isset($_POST['remove_product'])){

    $product_id = $_POST['product_id'];
    unset($_SESSION['cart'][$product_id]);

    calcTotalcart();

}else if(isset($_POST['edit_quantity'])){

    $product_id = $_POST['product_id']; 
    $product_quantity = $_POST['product_quantity'];

    $product_array = $_SESSION['cart'][$product_id];

    $product_array['product_quantity'] = $product_quantity;

    $_SESSION['cart'][$product_id] = $product_array;

    calcTotalcart();

}else{

}

function calcTotalcart(){

    $total = 0.00;

    foreach($_SESSION['cart'] as $key => $value){
        $product = $_SESSION['cart'][$key];

        $price = $product['product_price'];
        $quantity = $product['product_quantity'];

        $total = $total + ($price * $quantity);
        $tax = $total*0.06;
    }
    $_SESSION['total'] = $total;
}



?>

<!DOCTYPE html>
<html>
    <head>
        <title>Shopping Cart</title>

        <style>
            /*Banner*/
            *{
                margin: 0;
                padding: 0;
            }

            body{
                background-color: #e0e0e0;
                text-align: center;
            }

            .wrapper{
                width: 90%;
                margin: 0 auto;
            }

            header{
                width: 100%;
                height: 110px;
                background-color: #d54336;
                position: fixed;
                z-index: 1;
            }

            .logo{
                margin-top: 10px;
                float: left;
                width: 5%;
                max-width: 5%;
            }

            .img{
                width: 110%;
                max-width: 110%;
            }

            .nav1{
                margin-left: 20px;
                float: left;
                line-height: 100px;
            }

            .nav1 a{
                text-decoration: none;
                font-family: monospace;
                letter-spacing: 2px;
                font-size: 35px;
                color: #740c03;
                padding: 40px;
            }

            .ShoppingCart,.SplitScreen,.Profile{
                margin-top: 20px;  
            }

            nav a:hover{
                background-color: #740c03;
                color: white;
                font-weight:bold;
            }

            .dropdown a:link,.dropdown a:visited,.dropdown-content a:link,.dropdown-content a:visited{
                font-size: 16px;
                font-family: monospace;
                right: 10px;
                bottom: 30px;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                display: inline-block; 
                text-decoration: none;
            }

            .dropdown a:hover,.dropdown-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }   

            .dropdown a:active,.dropdown-content a:active{
                background-color: white;
                color: #740c03;
            }

            .dropdown{
                position: relative;
                display: inline-block;
            }

            .dropdown-content{
                right: 35px;
                top: 15px;
                display: none;
                position: absolute;
                font-size: 16px;
            }

            .dropdown:hover .dropdown-content{
                display: block;
            }

            .profile{
                font-family: monospace;
                font-size: 16px;
                display:inline; 
            }

            .profile-content a:link,.profile-content a:visited{
                font-size: 16px;
                font-family: monospace;
                background-color: white;
                color: #740c03;
                border:2px solid white;
                border-radius:20px; 
                text-align: center;
                padding: 10px 20px; 
                text-decoration: none;
                display:block;
            }

            .profile-content a:hover{
                font-family: monospace;
                background-color: #740c03;
                color: white;
                font-weight: bold;
            }

            .profile-content a:active{
                background-color: white;
                color: #740c03;
            }

            .profile-content{
                right: 48px;
                position: absolute;
                font-size: 16px;
                display: none;
                top: 90px;
            }

            .profile-content a{
                margin: 3px;
            }

            .profile:hover .profile-content{
                display: block;
            }


            /*Content*/
            .mycart{
                border-top:2px solid;
                border-bottom:2px solid;
                width:1100px;
                padding:10px;
            }

            .head{
                font-family: monospace;
                margin-right:1000px;
                font-size:30px;
            }

            .table1{
                margin-left:-900px;
            }

            .kun{
                border:2px solid;
                border-radius: 30px;
                width:50px;
            }

            .shopname{
                font-family: monospace;
                font-size:20px;
            }

            .attribute{
                font-family: monospace;
                font-size:15px;
                margin-left:50px;
            }

            .table2{
                margin-left:-40px;
            }

            .check{
                height:20px;
                width:20px;
            }

            .kun1{
                border:2px solid;
                border-radius: 30px;
                width:100px;
                max-width:100px;
                height:100px;
            }

            .text{
                font-family: monospace;
                font-size:20px;
            }

            .input{
                border-radius:30px;
                border:2px solid;
                padding:5px;
                width:60px;
                text-align: center;
            }

            .input:focus{
                background-color:#45657b;
                color:white;
            }

            .dustbin{
                color:#fb774b;
                text-decoration:none;
                font-size:20px;
                background-color:#e0e0e0;
                border:none;
                width:100%;
                cursor: pointer;
                font-weight:bold;
                font-family:monospace;
            }

            .total{
                font-family: monospace;
                font-size:17px;
                margin-right:-795px;
            }

            .table3{
                margin-right:-800px;
            }

            /*Sticky*/
            .imgContact{
                width: 40px;
                border: 3px solid white;
                border-radius: 50px;
                background-color: white;
            }

            .ContactUsWord a{
                font-family: monospace;
                font-weight: bold;
                text-decoration: none;
                font-size: 18px;
                line-height:45px;
                color: white;
                padding: 8px;
            }

            .ContactUsWord a:hover{
                color: #45657b;
            }

            .ContactUs{
                display: flex;
                position: fixed;
                margin-top: 600px;
                margin-left: 40px;
                border: 1px solid #00C9D8;
                border-radius: 50px;
                width: 170px;
                height: 45px;
                background-color: #00C9D8;
            }

            #top1{
                font-family: monospace;
                font-size: 30px;
                line-height: 55px;
                margin:auto;
                background-color: #45657b;
                width: 1300px;
                height: 50px;
                border-bottom: 5px solid #ffbd59;
            }

            .bbtn{
                margin-left:1100px;
                width:300px;
            }

            .btn{
                padding: 10px 30px;
                border-radius: 30px;
                font-family: monospace;
                border: 2px solid black;
                cursor: pointer;
                font-size: 15px;
                background-color: white;
                text-decoration: none;
                color: #740c03;
                margin-left: 20px;

            }

            .totalprice{
                font-family: monospace;
                font-size: 18px;
                margin-bottom: 15px;
                margin-left: 10px;
                border-top:3px solid red;
            }

            .edit_btn{
                color:#fb774b;
                text-decoration:none;
                font-size:12px;
                background-color:#e0e0e0;
                border:none;
                cursor: pointer;
                font-weight:bold;
                font-family:monospace;
            }
        </style>
    </head>

    <header>
    <div class="wrapper">
        <div class="logo">
            <a href="Home.php"><img src="../Resources/Web Application.png" class="img"></a>
        </div>

        <nav class="nav1">
            <a href="Shop.php">Shop</a>
            <a href="Community.php">Community</a>
            <a href="Video.php">Video</a>
            <a href="AboutUs.php">About Us</a>
        </nav>
            <div class="dropdown"><a href="Home.php" class="dropdown">ENGLISH &#11167;</a>
                <div class="dropdown-content">
                    <a href="Home(bm).php">MALAY</a>
                </div>
            </div>

            <a href="ShoppingCart.php"><img src="../Resources/kisspng-computer-icons-shopping-cart-shopping-cart-decoration-5ae1d7b85ac7e8.6820508115247502643719.png" width="5%" height="5%" class="ShoppingCart"></a>
            &nbsp;
            <a href="SplitScreen.php"><img src="../Resources/split-screen.png" width="5%" height="5%" class="SplitScreen"></a>
            &nbsp;&nbsp;
            <div class="profile"><img src="../Resources/computer-icons-user-profile-circle-abstract-449b748c464eba566641217282fff3a1.png" width="5%" height="5%">
                <div class="profile-content">
                    <a href="Profile.php">VIEW PROFILE</a>
                </div>
            </div>
    </div>
</header>

<div class="ContactUs">
    <a href="ContactUs.php"><img src="../Resources/contact.png" class="imgContact"></a>
    <div class="ContactUsWord">
        <a href="ContactUs.php">CONTACT US</a>
    </div>
</div>



        <!--Content-->
        <br><br><br><br><br><br><br>
            <caption id="top">
                <div id="top1">
                    <p><font style="color: white;">Shopping Cart</font></p>
                </div>
            </caption>

            <br><br>

        <center>
            <div>
                <table class="table2">
                    <tr>
                        <td></td>
                        <td class="attribute">Product Details</td>
                        <td class="attribute">Quantity</td>
                        <td class="attribute">Price</td>
                        <td class="attribute">Total Price</td>
                    </tr>
            
                <?php foreach($_SESSION['cart'] as $key => $value) {?>
                    <tr>
                        <td>
                            <img src="../Resources/<?php ECHO $value['product_image'];?>" class="kun1">
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </td>
                        <td>
                            <p1 class="text"><?php ECHO $value['product_name'];?></p1>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </td>
                        <td>
                            <form method="POST" action="ShoppingCart.php">
                                <input type="hidden" name="product_id" value="<?php ECHO $value['product_id'];?>"/>
                                <input type="number" name="product_quantity" value="<?php ECHO $value['product_quantity'];?>" class="input">
                                <input type="submit" class="edit_btn" value="EDIT" name="edit_quantity"/>
                                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                &nbsp;&nbsp;&nbsp;&nbsp;
                            </form>

                        </td>
                        <td>
                            <p1 class="text">RM<?php ECHO number_format($value['product_price'],2);?></p1>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;&nbsp;&nbsp;&nbsp;
                        </td>
                        <td>
                            <p1 class="text">RM<?php ECHO number_format($value['product_quantity'] * $value['product_price'],2);?></p1>
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                            &nbsp;
                        </td>
                        <td>
                            <form method="POST" action="ShoppingCart.php">
                                <input type="hidden" name="product_id" value="<?php ECHO $value['product_id'];?>"/>
                                <input type="submit" name="remove_product" value="REMOVE" class="dustbin"/>
                            </form>
                        </td>
                    </tr>

                    <tr></tr> <!-- padding between rows-->
                    <tr></tr>

                <?php }?>
                </table>
            </div>

            <div class="bbtn">
                <p class="totalprice"><b>Total Price : </b><font style="color: red;">RM<?php ECHO number_format($_SESSION['total'],2);?></font></p>
                <form method="POST" action="Payment.php">
                    <input type="submit" class="btn" value="CHECK OUT" name="checkout"/>
                </form>

            </div>

            <br><br><br><br><br><br><br>
        </center>
    </body>
</html>